# os-browserify

The [os](https://nodejs.org/api/os.html) module from node.js, but for browsers.

When you `require('os')` in [browserify](http://github.com/substack/node-browserify), this module will be loaded.
