# obuf - Offset buffer implementation.

Byte buffer specialized for data in chunks with special cases for dropping
bytes in the front, merging bytes in to various integer types and
abandoning buffer without penalty for previous chunk merges.

Used in spyd-transport, part of spdy support for http2.

This software is licensed under the MIT License.

By Fedor Indutny, 2015.

