exports.path = require("path").join(
  __dirname,
  "runtime.js"
);
